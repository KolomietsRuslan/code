<template>
    <div>
        Отзыв {{$route.params.id}}
    </div>
</template>