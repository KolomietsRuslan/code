<template>
    <div class="all_signin">
        <label style="text-align: start" for="login">{{label}}</label>
        <input id="login" v-model="inputValue" />
    </div>
</template>

<script>
    export default {
        data () {
            return {
                inputValue: '',
            };
        },
        props: {
            modelValue: {
                type: String,
                default: null,
            },
            label: {
                type: String,
                default: 'Поле ввода',
            },
        },
        watch: {
            modelValue: {
                handler () {
                    this.inputValue = this.modelValue;
                },
                immediate: true,
            },
            inputValue: {
                handler () {
                    this.$emit('update:modelValue', this.inputValue);
                }
            },
        },
    }
</script>

<style>
    .all_signin {
        display: flex;
        flex-direction: column;
        width: 50%;
        margin-left: 15px;
  }
</style>