<template>
  <div class="about">
    <h1>Пра миня</h1>
  </div>
</template>

<style>
  .about {

  }
</style>