<template>
    <div class="all_reviews">
        <h1>Отзывы</h1>
        <div class="reviews">
            <div v-for="review in reviewArray"
                :key="review.id">
                {{review.title}} <router-link :to="`/${review.id}`">Посмотреть отзыв</router-link>
            </div>
            <router-view />
        </div>
    </div>
</template>

<script>
    export default {
        data () {
            return {
                reviewArray: [
                    {
                        id: 1,
                        title: "Отзыв 1"
                    },
                        {
                        id: 2,
                        title: "Отзыв 2"
                    },
                ]
            }
        },
        methods: {
            onAdd () {
                this.$router.push('/reviews');
            },
        },
};
</script>

<style>
  .all_reviews {

  }
</style>