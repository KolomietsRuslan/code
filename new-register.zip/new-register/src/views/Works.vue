<template>
  <div class="works">
    <h1>Мои работы</h1>
  </div>
</template>

<style>
  .works {

  }
</style>