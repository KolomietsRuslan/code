<template>
  <div class="all_signin">
    <div class="signin">
      <h1>Вход</h1>
    </div>
    <my-input label="Логин" v-model="login" />
    <my-input label="Пароль:" v-model="password" />
    <div class="btn">
      <my-button label="Войти" type="submit" @click="doAuth"></my-button>
    </div>
  </div>
</template>

<script>
  import isAuth from '@/App.vue';
  export default {
          components: {
          },
          data () {
              return {
                  login: '',
                  password: '',
                  isAuth,
              };
          },
          methods: {
              doAuth () {
                this.isAuth = true;
              },
          },
  };
</script>

<style>
  #login {
    margin-bottom: 10px;
    font-size: 16px;
  }
  #password {
    margin-bottom: 10px;
    font-size: 16px;
  }
  .all_signin {
    display: flex;
    flex-direction: column;
  }
  .btn {
    margin-left: 15px;
  }
</style>