<template>
  <div class="authorize">
    <div class="authorize_text">
      <h1>Авторизация</h1>
    </div>
      <div class="login">Придумайте логин: <input v-model.trim="loginText" /></div>
      <div class="password">Придумайте пароль: <input v-model="passwordText" type="password" /></div>
      <div class="password">Подтвердите пароль: <input v-model.trim="passwordText" type="password"/></div>
      <button @click="onAdd">Зарегистрироваться</button>
  </div>
</template>

<script>
  export default {
          data () {
              return {
                  logIn: "",
                  password: "",
              };
          },
          methods: {
              onAdd () {
                  this.$router.push('/');
              },
          },
  };
</script>

<style>
  .authorize {

  }
</style>
