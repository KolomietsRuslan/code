<template>
    <div class="addreview">
        <h1>Добавление отзыва</h1>
        <div class="flex">
            <my-textarea label="Ваш отзыв:" />
            <my-button class="btn" label="Добавить" type="submit" @click="onAdd"></my-button>
            <div class="check">
                Согласны?<my-checkbox class="check" label="да" />
                        <my-checkbox class="check" label="нет" />
            </div>
            <div class="radio">
                Сколько вам лет?
                <my-radio class="radio" label="до 30" choice="1" name="1" v-model="first" />
                <my-radio class="radio" label="от 30" choice="2" name="2" v-model="first" />
            </div>
            <div class="select">
                <my-select />
            </div>
            <div>
                <my-button class="btn" label="Диалог" @click="dialogClick"></my-button>
                <my-dialog ref="dialog" @okClick="todo">
                    <template #header>
                    Введите данные:
                    </template>
                    <template #body>
                        <my-input label="Логин" v-model="login" />
                        <my-input label="Пароль:" v-model="password" />
                    </template>
                    <template #footer>
                    </template>
                </my-dialog>
            </div>
        </div>
    </div>
</template>

<script>
    import MyDialog from '@/components/ui/MyDialog.vue';
    export default {
        components: {MyDialog, },
        data () {
            return {
                first: '',
                shownDialog: false,
              };
        },
        methods: {
            onAdd () {
                this.$router.push('/reviews');
            },
            dialogClick () {
                this.$refs.dialog.show();
            },
            todo () {
                this.$router.push('/');
            },
        },
};
</script>

<style>
  .flex {
      display: flex;
      flex-direction: column;
      width: 50%;
  }
  .btn {
    text-align: start;
    width: 75px;
  }
  .check {
      text-align: start;
  }
  .select {
      user-select: none;
  }
</style>