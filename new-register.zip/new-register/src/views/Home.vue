<template>
  <div id="wrapper">
    Контентище
  </div>
</template>

<script>

</script>
